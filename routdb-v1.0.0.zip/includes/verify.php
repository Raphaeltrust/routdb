<head>
<!-- Chrome, Firefox OS and Opera -->
<meta name="theme-color" content="#00bfff">
<!-- Windows Phone -->
<meta name="msapplication-navbutton-color" content="#00bfff">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-status-bar-style" content="#00bfff">
<link rel='preconnect' href='https://fonts.gstatic.com'>
<link rel='preconnect' href='https://fonts.gstatic.com'>
<link rel='stylesheet' href='template/css/style.css'><meta name='viewport' content='width=device-width, initial-scale=1'></head><div style='height:100%;background:#dff1ff;width:100%;position:fixed;top:0;left:0;padding:15px;text-align:center'><h1 style='color:#00bfff;'>RoutDB</h1><p>We could not connect to the server you specified. There was an error validating the server please make sure the Servername, Username and Password are correct</p> <br> <a href='close.php'><button style='background:#00bfff;padding:10px;border-radius:5px; color:#fff;box-shadow:1px 1px 5px gray;border:none;outline:none;font-weight:500;'>Connect Again</button></a></div>